import type { Metadata } from "next"
import { MarketingHeader } from "@/components/marketing/header"
import { MarketingFooter } from "@/components/marketing/footer"
import { LiveChatWidget } from "@/components/live-chat-widget"

export const metadata: Metadata = {
  title: {
    template: "%s | Replyma",
    default: "Replyma - AI-Powered Customer Support for E-commerce",
  },
  description:
    "Resolve up to 80% of support tickets automatically with AI. Unified inbox for Email and Live Chat. Built for Shopify and e-commerce.",
  keywords: [
    "AI customer support",
    "e-commerce helpdesk",
    "Shopify support",
    "unified inbox",
    "AI auto-reply",
    "customer service automation",
    "live chat",
    "Replyma",
  ],
  authors: [{ name: "Replyma" }],
  creator: "Replyma",
  publisher: "Replyma",
  openGraph: {
    type: "website",
    locale: "en_US",
    siteName: "Replyma",
    title: "Replyma - AI-Powered Customer Support for E-commerce",
    description:
      "Resolve up to 80% of support tickets automatically with AI. Unified inbox for Email and Live Chat. Built for Shopify and e-commerce.",
  },
  twitter: {
    card: "summary_large_image",
    title: "Replyma - AI-Powered Customer Support for E-commerce",
    description:
      "Resolve up to 80% of support tickets automatically with AI. Unified inbox for Email and Live Chat.",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
}

export default function MarketingLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen flex-col bg-background">
      <MarketingHeader />
      <main id="main-content" className="flex-1">{children}</main>
      <MarketingFooter />
      <LiveChatWidget
        workspaceId="cmmbvaqlu000gj550x9hhkcqu"
        assistantName="Replyma AI"
        greeting="Hi! 👋 I'm the Replyma AI assistant. Ask me anything about our platform — pricing, features, integrations, or how to get started."
        quickReplies={["How does AI auto-reply work?", "See pricing plans", "How to connect Shopify?"]}
        proactiveTitle="Curious how AI can handle your support?"
        proactiveSubtitle="Ask me anything about Replyma"
        proactiveTriggerDelay={20}
        accentColor="#0a0a0a"
        floatingOnly
        floatingPanelBottomOffset={72}
      />
    </div>
  )
}
