# Live Chat Widget — Design & Animation

Копія файлів, що відповідають за **дизайн, анімації та кнопки** віджету лайв-чату та самого лайв-чату.

## Структура

| Файл | Призначення |
|------|-------------|
| **components/live-chat-widget.tsx** | Основний компонент віджету: дизайн панелі, кнопка (FAB), анімації (framer-motion), кольори, бульбашки повідомлень, proactive-блок, quick replies. |
| **app/widget/layout.tsx** | Layout сторінки віджету (iframe). |
| **app/widget/[workspaceId]/page.tsx** | Сторінка віджету за workspaceId. |
| **app/widget/[workspaceId]/widget-client.tsx** | Клієнт віджету: рендер `LiveChatWidget` з параметрами для embed. |
| **app/(marketing)/layout.tsx** | Layout маркетингу: підключення `LiveChatWidget` на replyma.com (кнопка + панель чату). |
| **app/(marketing)/features/live-chat/page.tsx** | Сторінка features/live-chat: мокап чату та опис фічі. |
| **app/(marketing)/features/live-chat/layout.tsx** | Layout сторінки features/live-chat. |
| **public/widget.js** | Скрипт для вбудовування віджету на сторонні сайти (кнопка, iframe, подія відкриття). |

Файли **скопійовані** (оригінали залишились на місці).
