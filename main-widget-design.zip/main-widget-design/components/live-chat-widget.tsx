"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import { motion, AnimatePresence, useReducedMotion } from "framer-motion"
import { X, MessageSquare, Send, Sparkles, ArrowDown, ShoppingBag } from "lucide-react"
import { subscribeToLivechat, unsubscribeFromLivechat, PusherEvents } from "@/lib/pusher-client"

/** Product summary for Shopping Assistant cards (from AI message metadata.products). */
interface ProductSummary {
  id: string
  title: string
  handle: string
  featuredImage?: string
  price: string
  variantId: string
}

interface Message {
  id: string
  role: "customer" | "ai"
  content: string
  time: string
  quickReplies?: string[]
  products?: ProductSummary[]
}

interface LiveChatWidgetProps {
  workspaceId?: string
  proactiveTriggerDelay?: number
  greeting?: string
  accentColor?: string
  accentGradientPreset?: string
  textIconColor?: string
  headerTextColor?: string
  headerSubtextColor?: string
  panelBackgroundColor?: string
  assistantBubbleColor?: string
  assistantTextColor?: string
  userBubbleColor?: string
  userTextColor?: string
  inputBackgroundColor?: string
  inputTextColor?: string
  quickReplyBackgroundColor?: string
  quickReplyTextColor?: string
  quickReplyBorderColor?: string
  launcherIconColor?: string
  proactiveBackgroundColor?: string
  proactiveTextColor?: string
  proactiveSubtextColor?: string
  quickReplies?: string[]
  proactiveTitle?: string
  proactiveSubtitle?: string
  assistantName?: string
  /** When true, desktop opens as floating box above FAB. Mobile behavior depends on embedMode/forceDesktopLayout. */
  floatingOnly?: boolean
  /** Bottom offset for floating panel in px (when floatingOnly=true). */
  floatingPanelBottomOffset?: number
  /** When true, apply embed-specific design (used on customer sites). Same behavior, slightly different look. */
  embedMode?: boolean
  /** Force desktop paddings/sizes even inside narrow iframe viewport. */
  forceDesktopLayout?: boolean
}

const EMBED_DESKTOP_LAUNCHER_INSET_PX = 10
/** Symmetric inset so panel shadow has equal room left and right (no cut-off left, no excess right). */
const EMBED_PANEL_HORIZ_INSET_PX = 10
const EMBED_PROTOCOL_VERSION = 1
const MSG_READY = "replyma:ready"
const MSG_SET_STATE = "replyma:set-state"
const MSG_STATE_REQUEST = "replyma:state-request"
const MSG_STATE_APPLIED = "replyma:state-applied"
const MSG_LEGACY_RESIZE = "replyma:widget:resize"
const MSG_LEGACY_RESIZE_DONE = "replyma:widget:resizeDone"
const MSG_RESIZE_DONE = "replyma:resize-done"
const EMBED_OPEN_ACK_FALLBACK_MS = 400

/** Launcher icon size (24px in 56px button). */
const LAUNCHER_ICON_SIZE = 24

/** Launcher button: MessageSquare (Lucide) icon, animates to X when open. */
function LauncherButton({
  isOpen,
  onToggle,
  embedMode,
  reducedMotion,
  background,
  iconColor,
  auraBackground,
  unread,
}: {
  isOpen: boolean
  onToggle: () => void
  embedMode: boolean
  reducedMotion: boolean
  background: string
  iconColor: string
  auraBackground: string
  unread: number
}) {
  const iconTransition = { type: "tween" as const, duration: reducedMotion ? 0 : 0.22, ease: [0.25, 0.1, 0.25, 1] }
  return (
    <motion.button
      type="button"
      onClick={onToggle}
      whileTap={reducedMotion ? undefined : { scale: 0.97 }}
      transition={{ duration: 0.15 }}
      className="relative flex h-14 w-14 items-center justify-center rounded-full shadow-[0_2px_20px_rgba(0,0,0,0.08)] hover:shadow-[0_4px_28px_rgba(0,0,0,0.10)] transition-shadow duration-200 touch-manipulation overflow-hidden"
      style={{
        background: embedMode ? (background || "#0a0a0a") : background,
        color: iconColor,
        ...(embedMode ? { WebkitBackfaceVisibility: "hidden" as const, backfaceVisibility: "hidden" as const, isolation: "isolate" as const } : {}),
      }}
      aria-label={isOpen ? "Close chat" : "Open chat"}
    >
      {/* Aura: static (no animation) to prevent repaint flicker */}
      <span
        aria-hidden
        className="pointer-events-none absolute rounded-full -inset-2.5"
        style={{ background: auraBackground, opacity: 0.55 }}
      />
      <span className="relative flex items-center justify-center overflow-hidden" style={{ width: LAUNCHER_ICON_SIZE, height: LAUNCHER_ICON_SIZE }}>
        <AnimatePresence initial={false} mode="wait">
          {isOpen ? (
            <motion.span
              key="close"
              initial={{ opacity: 0, rotate: -45 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0, rotate: 45 }}
              transition={iconTransition}
              className="absolute inset-0 flex items-center justify-center"
            >
              <X size={LAUNCHER_ICON_SIZE} className="shrink-0" />
            </motion.span>
          ) : (
            <motion.span
              key="chat"
              initial={{ opacity: 0, rotate: 45 }}
              animate={{ opacity: 1, rotate: 0 }}
              exit={{ opacity: 0, rotate: -45 }}
              transition={iconTransition}
              className="absolute inset-0 flex items-center justify-center"
            >
              <MessageSquare size={LAUNCHER_ICON_SIZE} className="shrink-0" />
            </motion.span>
          )}
        </AnimatePresence>
      </span>
      {!isOpen && unread > 0 && (
        <span className="absolute -top-0.5 -right-0.5 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-[10px] font-bold text-white shadow-[0_1px_3px_rgba(0,0,0,0.2)]">
          {unread > 9 ? "9+" : unread}
        </span>
      )}
    </motion.button>
  )
}

let msgCounter = 0
function uid() { return `m-${Date.now()}-${++msgCounter}` }
function getTime() { return new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }) }
function toRgba(color: string, alpha: number): string {
  const fallback = `rgba(10, 10, 10, ${alpha})`
  try {
    const hex = color.trim().replace("#", "")
    const full = hex.length === 3 ? hex.split("").map((c) => c + c).join("") : hex
    if (full.length !== 6) return fallback
    const r = parseInt(full.slice(0, 2), 16)
    const g = parseInt(full.slice(2, 4), 16)
    const b = parseInt(full.slice(4, 6), 16)
    if ([r, g, b].some((n) => Number.isNaN(n))) return fallback
    return `rgba(${r}, ${g}, ${b}, ${alpha})`
  } catch {
    return fallback
  }
}

function parseOrigin(url: string): string | null {
  try {
    return new URL(url).origin
  } catch {
    return null
  }
}

export function LiveChatWidget({
  workspaceId = "",
  proactiveTriggerDelay = 10,
  greeting = "Hi there! 👋 How can I help you today?",
  accentColor,
  accentGradientPreset = "none",
  textIconColor,
  headerTextColor = "#ffffff",
  headerSubtextColor = "#d9d9d9",
  panelBackgroundColor = "#f8f9fa",
  assistantBubbleColor = "#ffffff",
  assistantTextColor = "#1a1a1a",
  userBubbleColor,
  userTextColor = "#ffffff",
  inputBackgroundColor = "#f5f5f5",
  inputTextColor = "#1a1a1a",
  quickReplyBackgroundColor = "#ffffff",
  quickReplyTextColor = "#333333",
  quickReplyBorderColor = "#e5e7eb",
  launcherIconColor = "#ffffff",
  proactiveBackgroundColor = "#ffffff",
  proactiveTextColor = "#1a1a1a",
  proactiveSubtextColor = "#888888",
  quickReplies: defaultQuickReplies = ["Track my order", "Return or exchange", "Product question"],
  proactiveTitle = "Need help finding the right product?",
  proactiveSubtitle = "Our AI assistant can help you decide",
  assistantName = "AI Shopping Assistant",
  floatingOnly = false,
  floatingPanelBottomOffset = 72,
  embedMode = false,
  forceDesktopLayout = false,
}: LiveChatWidgetProps) {
  // Keep the same visual baseline in marketing and embedded widget; workspace settings still override this.
  const resolvedAccent = accentColor ?? "#0a0a0a"
  const resolvedUserBubbleColor = userBubbleColor ?? resolvedAccent
function getContrastingColor(value: string): string {
  try {
    const hex = value.replace("#", "")
    const full = hex.length === 3 ? hex.split("").map((c) => c + c).join("") : hex
    if (full.length !== 6) return "#ffffff"
    const r = parseInt(full.slice(0, 2), 16)
    const g = parseInt(full.slice(2, 4), 16)
    const b = parseInt(full.slice(4, 6), 16)
    const yiq = (r * 299 + g * 587 + b * 114) / 1000
    return yiq >= 160 ? "#0f172a" : "#ffffff"
  } catch {
    return "#ffffff"
  }
}

const gradientMap: Record<string, [string, string]> = {
    sunset: ["#ff3b00", "#ff00a8"],
    ocean: ["#0047ff", "#00e5ff"],
    aurora: ["#00d84a", "#00b8ff"],
  }
  const accentGradient = gradientMap[accentGradientPreset]
  const accentSurfaceBackground = accentGradient
    ? `linear-gradient(135deg, ${accentGradient[0]}, ${accentGradient[1]})`
    : resolvedAccent
  const accentBorderColor = accentGradient ? accentGradient[1] : resolvedAccent
  const accentTextSource = accentGradient ? accentGradient[1] : resolvedAccent
  const accentTextAndIconColor = textIconColor ?? getContrastingColor(accentTextSource)
  const headerPrimaryColor = headerTextColor || accentTextAndIconColor
  const headerSecondaryColor = headerSubtextColor || accentTextAndIconColor
  const assistantMessageColor = assistantTextColor || "#1a1a1a"
  const customerMessageColor = userTextColor || accentTextAndIconColor
  const inputFieldTextColor = inputTextColor || "#1a1a1a"
  const quickReplyChipTextColor = quickReplyTextColor || accentTextAndIconColor
  const launcherGlyphColor = launcherIconColor || accentTextAndIconColor
  const proactivePrimaryColor = proactiveTextColor || accentTextAndIconColor
  const proactiveSecondaryColor = proactiveSubtextColor || proactivePrimaryColor
  const compactEmbedSizing = embedMode && !forceDesktopLayout
  const prefersReducedMotion = useReducedMotion()
  const mobileFullscreenOpen = !floatingOnly || (!embedMode && !forceDesktopLayout)
  const launcherAuraBackground = accentGradient
    ? `radial-gradient(circle, ${toRgba(accentGradient[1], 0.38)} 0%, ${toRgba(accentGradient[0], 0.2)} 45%, rgba(0,0,0,0) 74%)`
    : `radial-gradient(circle, ${toRgba(resolvedAccent, 0.34)} 0%, rgba(0,0,0,0) 74%)`
  const widgetApiBase = process.env.NEXT_PUBLIC_API_URL || "http://localhost:4000/api/v1"
  const [open, setOpen] = useState(false)
  const [isPhoneViewport, setIsPhoneViewport] = useState(false)
  /** In embed with desktop host, iframe is narrow (368px) so matchMedia would say "phone"; use desktop animation anyway. */
  const useDesktopPanelAnimation = !embedMode ? !isPhoneViewport : (forceDesktopLayout || !isPhoneViewport)
  /** In embed, treat as mobile (full screen + hide launcher when open) only when host said mobile (desktop=0). Do not use isPhoneViewport — iframe is 368px on desktop so it would wrongly force mobile. */
  const embedMobile = embedMode && !forceDesktopLayout
  const [messages, setMessages] = useState<Message[]>([])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const [showScrollBtn, setShowScrollBtn] = useState(false)
  const [unread, setUnread] = useState(0)
  const [proactiveShown, setProactiveShown] = useState(false)
  const [proactiveDismissed, setProactiveDismissed] = useState(false)
  const [proactiveMessage, setProactiveMessage] = useState<string | null>(null)
  const mountTimeRef = useRef(Date.now())
  const sessionContextRef = useRef<{ cartValue?: number; currentUrl?: string; exitIntent?: boolean }>({})
  const [customerEmail, setCustomerEmail] = useState("")
  const [emailCollected, setEmailCollected] = useState(false)
  const [customerMsgCount, setCustomerMsgCount] = useState(0)
  const scrollRef = useRef<HTMLDivElement>(null)
  const inputRef = useRef<HTMLInputElement>(null)
  const openRef = useRef(open)
  openRef.current = open
  const emailRef = useRef(customerEmail)
  emailRef.current = customerEmail
  const [sessionId] = useState(() =>
    typeof crypto !== "undefined" && crypto.randomUUID
      ? crypto.randomUUID()
      : `s-${Date.now()}-${Math.random().toString(36).slice(2)}`
  )
  const [ticketId, setTicketId] = useState<string | null>(null)
  const [apiAvailable, setApiAvailable] = useState(true)
  /** In embed: stay "open" until panel exit animation finishes, so iframe doesn't shrink during close. */
  const [embedExiting, setEmbedExiting] = useState(false)
  const pusherBoundRef = useRef(false)
  const replyTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const parentOriginRef = useRef<string | null>(null)
  const requestSeqRef = useRef(0)
  const awaitingOpenRequestIdRef = useRef<number | null>(null)
  const lastSentModeRef = useRef<"open" | "proactive" | "closed" | null>(null)
  const wasOpenRef = useRef(open)
  const pendingOpenRef = useRef(false)

  useEffect(() => {
    if (typeof window === "undefined") return
    parentOriginRef.current = parseOrigin(document.referrer)
    const mq = window.matchMedia("(max-width: 639px)")
    const apply = () => setIsPhoneViewport(mq.matches)
    apply()
    if (mq.addEventListener) {
      mq.addEventListener("change", apply)
      return () => mq.removeEventListener("change", apply)
    }
    mq.addListener(apply)
    return () => mq.removeListener(apply)
  }, [])

  useEffect(() => {
    if (!embedMode) {
      wasOpenRef.current = open
      return
    }
    if (wasOpenRef.current && !open) {
      setEmbedExiting(true)
    }
    wasOpenRef.current = open
  }, [embedMode, open])

  // ─── Session context: send to backend and fetch proactive message ───
  const sendSessionContextAndMaybeProactive = useCallback(
    async (dwellTimeSeconds?: number, exitIntent?: boolean) => {
      if (!workspaceId) return
      const ctx = sessionContextRef.current
      const payload = {
        workspaceId,
        sessionId,
        cartValue: ctx.cartValue,
        dwellTimeSeconds: dwellTimeSeconds ?? Math.floor((Date.now() - mountTimeRef.current) / 1000),
        currentUrl: ctx.currentUrl,
        exitIntent: exitIntent ?? ctx.exitIntent,
      }
      try {
        await fetch(`${widgetApiBase}/widget/session-context`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        })
      } catch { /* ignore */ }
      try {
        const res = await fetch(
          `${widgetApiBase}/widget/proactive?workspaceId=${encodeURIComponent(workspaceId)}&sessionId=${encodeURIComponent(sessionId)}`
        )
        if (!res.ok) return
        const data = (await res.json()) as { message?: string | null }
        if (data.message) setProactiveMessage(data.message)
      } catch { /* ignore */ }
    },
    [workspaceId, sessionId, widgetApiBase],
  )

  // ─── Proactive: dwell-time trigger ─── (send context + fetch proactive, then show)
  useEffect(() => {
    if (!proactiveTriggerDelay || open || proactiveDismissed) return
    const t = setTimeout(async () => {
      await sendSessionContextAndMaybeProactive()
      setProactiveShown(true)
    }, proactiveTriggerDelay * 1000)
    return () => clearTimeout(t)
  }, [proactiveTriggerDelay, open, proactiveDismissed, sendSessionContextAndMaybeProactive])

  // ─── Proactive: exit-intent (desktop) ───
  useEffect(() => {
    if (open || proactiveDismissed) return
    const handler = async (e: MouseEvent) => {
      if (e.clientY <= 5) {
        await sendSessionContextAndMaybeProactive(undefined, true)
        setProactiveShown(true)
      }
    }
    document.addEventListener("mouseout", handler)
    return () => document.removeEventListener("mouseout", handler)
  }, [open, proactiveDismissed, sendSessionContextAndMaybeProactive])

  // ─── Initial session context (so backend has session key) ───
  useEffect(() => {
    if (!workspaceId) return
    fetch(`${widgetApiBase}/widget/session-context`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ workspaceId, sessionId, dwellTimeSeconds: 0 }),
    }).catch(() => {})
  }, [workspaceId, sessionId, widgetApiBase])

  // ─── Listen for replyma:sessionContext from parent page ───
  useEffect(() => {
    if (typeof window === "undefined" || window.parent === window) return
    const handler = (e: MessageEvent) => {
      const data = (e.data || {}) as Record<string, unknown>
      if (data.type !== "replyma:sessionContext") return
      const payload = data.payload as Record<string, unknown> | undefined
      if (payload) {
        if (typeof payload.cartValue === "number") sessionContextRef.current.cartValue = payload.cartValue
        if (typeof payload.currentUrl === "string") sessionContextRef.current.currentUrl = payload.currentUrl
        if (payload.exitIntent === true) sessionContextRef.current.exitIntent = true
      }
      if (workspaceId) {
        sendSessionContextAndMaybeProactive(
          typeof payload?.dwellTimeSeconds === "number" ? payload.dwellTimeSeconds : undefined,
          payload?.exitIntent === true,
        ).catch(() => {})
      }
    }
    window.addEventListener("message", handler)
    return () => window.removeEventListener("message", handler)
  }, [workspaceId, sendSessionContextAndMaybeProactive])

  // ─── Greeting on first open ───
  const greetingDone = useRef(false)
  useEffect(() => {
    if (open && !greetingDone.current) {
      greetingDone.current = true
      setProactiveShown(false)
      const t = setTimeout(() => {
        setMessages([{ id: uid(), role: "ai", content: greeting, time: getTime(), quickReplies: defaultQuickReplies }])
      }, 250)
      return () => clearTimeout(t)
    }
  }, [open, greeting, defaultQuickReplies])

  // ─── Auto-scroll to bottom ───
  const scrollToEnd = useCallback(() => {
    requestAnimationFrame(() => {
      scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" })
    })
  }, [])

  useEffect(() => {
    if (!scrollRef.current) return
    const el = scrollRef.current
    const near = el.scrollHeight - el.scrollTop - el.clientHeight < 150
    if (near) scrollToEnd()
  }, [messages, isTyping, scrollToEnd])

  // ─── Scroll to bottom when re-opening ───
  useEffect(() => {
    if (open && messages.length > 0) scrollToEnd()
  }, [open, scrollToEnd, messages.length])

  // ─── Scroll-to-bottom button tracking ───
  useEffect(() => {
    const el = scrollRef.current
    if (!el) return
    const fn = () => setShowScrollBtn(el.scrollHeight - el.scrollTop - el.clientHeight > 150)
    el.addEventListener("scroll", fn, { passive: true })
    return () => el.removeEventListener("scroll", fn)
  }, [])

  // ─── Focus input on open ───
  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 250)
  }, [open])

  // ─── Lock body scroll on mobile (only when panel is full-screen) ───
  useEffect(() => {
    if (!open || !mobileFullscreenOpen || embedMode) return
    const mq = window.matchMedia("(max-width: 639px)")
    if (!mq.matches) return
    const y = window.scrollY
    Object.assign(document.body.style, { position: "fixed", top: `-${y}px`, left: "0", right: "0", overflow: "hidden" })
    return () => {
      Object.assign(document.body.style, { position: "", top: "", left: "", right: "", overflow: "" })
      window.scrollTo(0, y)
    }
  }, [open, mobileFullscreenOpen, embedMode])

  const postToParent = useCallback((payload: Record<string, unknown>) => {
    if (typeof window === "undefined" || window.parent === window) return
    const targetOrigin = parentOriginRef.current ?? "*"
    window.parent.postMessage(payload, targetOrigin)
  }, [])

  /** Sync state to parent (closed/proactive/open). Does not request ack. */
  const sendStateToParent = useCallback(
    (state: "open" | "proactive" | "closed") => {
      postToParent({ type: MSG_SET_STATE, version: EMBED_PROTOCOL_VERSION, state })
      postToParent({ type: MSG_LEGACY_RESIZE, mode: state, accentColor: resolvedAccent })
    },
    [postToParent, resolvedAccent],
  )

  /** Request open and wait for parent ack (desktop embed). Sets pendingOpenRef; ack handler or fallback calls applyEmbedOpen. */
  const requestOpenAndWait = useCallback(() => {
    requestSeqRef.current += 1
    const requestId = requestSeqRef.current
    pendingOpenRef.current = true
    awaitingOpenRequestIdRef.current = requestId
    postToParent({ type: MSG_STATE_REQUEST, version: EMBED_PROTOCOL_VERSION, requestId, state: "open" })
    postToParent({ type: MSG_LEGACY_RESIZE, mode: "open", accentColor: resolvedAccent })
  }, [postToParent, resolvedAccent])

  const embedOpenFallbackRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const applyEmbedOpen = useCallback(() => {
    if (embedOpenFallbackRef.current) {
      clearTimeout(embedOpenFallbackRef.current)
      embedOpenFallbackRef.current = null
    }
    setOpen(true)
    setUnread(0)
    setProactiveShown(false)
    pendingOpenRef.current = false
    awaitingOpenRequestIdRef.current = null
  }, [])

  useEffect(() => {
    if (!embedMode) return
    let cancelled = false
    const id1 = requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        if (!cancelled) postToParent({ type: MSG_READY, version: EMBED_PROTOCOL_VERSION })
      })
    })
    return () => {
      cancelled = true
      cancelAnimationFrame(id1)
    }
  }, [embedMode, postToParent])

  useEffect(() => {
    if (!embedMode || typeof window === "undefined") return
    const handler = (e: MessageEvent) => {
      if (e.source !== window.parent) return
      const allowed =
        !parentOriginRef.current ||
        e.origin === parentOriginRef.current ||
        e.origin === window.location.origin
      if (!allowed) return
      const data = (e.data || {}) as Record<string, unknown>
      if (!pendingOpenRef.current || typeof data.type !== "string") return
      const isOpenAck =
        (data.type === MSG_STATE_APPLIED && data.state === "open" && data.requestId === awaitingOpenRequestIdRef.current) ||
        data.type === MSG_RESIZE_DONE ||
        data.type === MSG_LEGACY_RESIZE_DONE
      if (isOpenAck) {
        applyEmbedOpen()
      }
    }
    window.addEventListener("message", handler)
    return () => window.removeEventListener("message", handler)
  }, [embedMode, applyEmbedOpen])

  useEffect(() => () => {
    if (embedOpenFallbackRef.current) clearTimeout(embedOpenFallbackRef.current)
  }, [])

  const displayState: "open" | "proactive" | "closed" =
    open ? "open" : proactiveShown && !proactiveDismissed ? "proactive" : embedExiting ? "open" : "closed"
  useEffect(() => {
    if (!embedMode) return
    if (lastSentModeRef.current === displayState) return
    lastSentModeRef.current = displayState
    sendStateToParent(displayState)
  }, [embedMode, displayState, sendStateToParent])

  const handleLauncherOpen = useCallback(() => {
    if (embedMobile) {
      sendStateToParent("open")
      setOpen(true)
      setUnread(0)
      setProactiveShown(false)
    } else if (embedMode) {
      if (pendingOpenRef.current) return
      setOpen(true)
      setUnread(0)
      setProactiveShown(false)
      requestOpenAndWait()
      embedOpenFallbackRef.current = setTimeout(() => {
        if (pendingOpenRef.current) applyEmbedOpen()
        embedOpenFallbackRef.current = null
      }, EMBED_OPEN_ACK_FALLBACK_MS)
    } else {
      setOpen(true)
      setUnread(0)
      setProactiveShown(false)
    }
  }, [embedMobile, embedMode, sendStateToParent, requestOpenAndWait, applyEmbedOpen])

  // ─── Pusher: real-time AI replies ───
  useEffect(() => {
    if (!workspaceId || pusherBoundRef.current) return
    try {
      const ch = subscribeToLivechat(workspaceId, sessionId)
      pusherBoundRef.current = true
      ch.bind(PusherEvents.MESSAGE_NEW, (data: {
        ticketId: string
        message?: { role: string; content: string; metadata?: { products?: ProductSummary[]; quickReplies?: string[] } }
      }) => {
        const role = data.message?.role
        const content = data.message?.content
        if (!role || !content || (role !== "AI" && role !== "HUMAN")) return
        const products = data.message?.metadata?.products as ProductSummary[] | undefined
        const quickReplies = data.message?.metadata?.quickReplies as string[] | undefined
        setTicketId((cur) => {
          if (cur && data.ticketId === cur) {
            if (replyTimerRef.current) { clearTimeout(replyTimerRef.current); replyTimerRef.current = null }
            setIsTyping(false)
            setMessages((prev) => [...prev, {
              id: uid(),
              role: "ai",
              content,
              time: getTime(),
              ...(products?.length ? { products } : {}),
              ...(quickReplies?.length ? { quickReplies } : {}),
            }])
            if (!openRef.current) setUnread((n) => n + 1)
          }
          return cur
        })
      })
      return () => { ch.unbind_all(); unsubscribeFromLivechat(workspaceId, sessionId); pusherBoundRef.current = false }
    } catch { /* pusher unavailable */ }
  }, [workspaceId])

  // ─── Cleanup timer on unmount ───
  useEffect(() => () => { if (replyTimerRef.current) clearTimeout(replyTimerRef.current) }, [])

  // ─── Send message ───
  const sendMessage = useCallback(async (text: string) => {
    const msg = text.trim()
    if (!msg || isTyping) return
    setMessages((prev) => [...prev, { id: uid(), role: "customer", content: msg, time: getTime() }])
    setCustomerMsgCount((n) => n + 1)
    setInput("")

    if (!workspaceId || !apiAvailable) {
      setIsTyping(true)
      replyTimerRef.current = setTimeout(() => {
        replyTimerRef.current = null; setIsTyping(false)
        setMessages((p) => [...p, { id: uid(), role: "ai", content: "Thanks for your message! Our team will get back to you shortly.", time: getTime() }])
      }, 1500)
      return
    }

    setIsTyping(true)
    try {
      const res = await fetch(`${widgetApiBase}/webhooks/livechat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ workspaceId, email: emailRef.current, name: "", message: msg, sessionId }),
      })
      if (!res.ok) throw new Error(`${res.status}`)
      const data = await res.json()
      if (data.ticketId) setTicketId(data.ticketId)
      replyTimerRef.current = setTimeout(() => {
        replyTimerRef.current = null
        setIsTyping((c) => {
          if (c) { setMessages((p) => [...p, { id: uid(), role: "ai", content: "Thanks for your patience! Our team is looking into this.", time: getTime() }]); return false }
          return c
        })
      }, 20000)
    } catch {
      setApiAvailable(false); setIsTyping(false)
      setMessages((p) => [...p, { id: uid(), role: "ai", content: "Our team will get back to you shortly.", time: getTime() }])
    }
  }, [isTyping, workspaceId, apiAvailable, sessionId])

  function handleSend() { sendMessage(input) }
  function handleQuickReply(text: string) { sendMessage(text) }
  function handleCloseChat() {
    inputRef.current?.blur()
    if (embedMode) {
      setEmbedExiting(true) // Keep telling parent "open" until panel exit animation completes; avoids iframe shrink-then-grow "reload" on customer sites.
      setProactiveShown(false) // Avoid sending "proactive" right after close so container stays closed (76px) and doesn't flicker to proactive size ~1s later.
    }
    setOpen(false)
  }

  // ─── Message grouping helpers ───
  function isFirst(i: number) { return i === 0 || messages[i - 1]?.role !== messages[i]?.role }
  function isLast(i: number) { return i === messages.length - 1 || messages[i + 1]?.role !== messages[i]?.role }

  // ─── Bubble border-radius ───
  function bubbleRadius(isCustomer: boolean, first: boolean, last: boolean) {
    if (first && last) return "rounded-2xl"
    if (isCustomer) return first ? "rounded-2xl rounded-br-lg" : last ? "rounded-2xl rounded-tr-lg" : "rounded-r-lg rounded-l-2xl"
    return first ? "rounded-2xl rounded-bl-lg" : last ? "rounded-2xl rounded-tl-lg" : "rounded-r-2xl rounded-l-lg"
  }

  return (
    <div
      className={`fixed z-[999999] pointer-events-none [&>*]:pointer-events-auto ${
        embedMode ? "inset-0" : "bottom-0 right-0 sm:bottom-5 sm:right-5 pb-[env(safe-area-inset-bottom)]"
      }`}
      style={embedMode ? { background: "transparent", WebkitTextSizeAdjust: "100%", textSizeAdjust: "100%" } : undefined}
    >

      {/* ─── Chat window: only in DOM when open so closed state never paints white ─── */}
      <AnimatePresence
        onExitComplete={() => {
          if (embedMode && embedExiting) {
            // Exit animation finished: parent can safely shrink iframe to closed size.
            setEmbedExiting(false)
          }
        }}
      >
        {open && (
          <motion.div
            initial={
              prefersReducedMotion
                ? { opacity: 1, y: 0 }
                : useDesktopPanelAnimation
                  ? { opacity: 0, y: 16 }
                  : { opacity: 0, y: 20 }
            }
            animate={{ opacity: 1, y: 0 }}
            exit={prefersReducedMotion || !useDesktopPanelAnimation ? { opacity: 0, y: 0 } : { opacity: 0, y: 12 }}
            transition={
              prefersReducedMotion || !useDesktopPanelAnimation
                ? { duration: 0 }
                : { duration: 0.28, ease: [0.25, 0.1, 0.25, 1] }
            }
            className={`flex flex-col overflow-visible pointer-events-auto z-0
              ${floatingOnly
                ? forceDesktopLayout
                  ? "absolute right-0 bottom-[72px] h-[540px] w-[368px] rounded-2xl"
                  : embedMode
                  ? (embedMobile
                      ? "fixed inset-0 rounded-t-2xl"
                      : "absolute left-[10px] right-[10px] bottom-[72px] h-[540px] w-[calc(100%-20px)] max-w-[358px] rounded-2xl")
                    : "fixed inset-0 sm:absolute sm:inset-auto sm:right-0 sm:bottom-[72px] sm:h-[540px] sm:w-[368px] rounded-t-2xl sm:rounded-2xl"
                : embedMode
                  ? (embedMobile
                      ? "fixed inset-0 rounded-t-2xl"
                      : "absolute left-[10px] right-[10px] bottom-[72px] h-[540px] w-[calc(100%-20px)] max-w-[358px] rounded-2xl")
                  : "fixed inset-0 sm:absolute sm:inset-auto sm:bottom-[72px] sm:right-0 sm:h-[540px] sm:w-[368px] rounded-t-2xl sm:rounded-2xl"
              }
            `}
            style={{
              ...(floatingOnly ? { bottom: `${floatingPanelBottomOffset}px` } : {}),
              ...(embedMobile ? { position: "fixed" as const, top: 0, left: 0, right: 0, bottom: 0, width: "100%", height: "100%", minHeight: "100dvh" } : {}),
              ...(embedMode && !embedMobile ? { position: "absolute" as const, left: EMBED_PANEL_HORIZ_INSET_PX, right: EMBED_PANEL_HORIZ_INSET_PX, bottom: 72, width: "auto", height: 540 } : {}),
              ...(floatingOnly && !embedMode && isPhoneViewport ? { position: "fixed" as const, top: 0, left: 0, right: 0, bottom: 0, width: "100%", height: "100%", minHeight: "100dvh" } : {}),
              backgroundColor: "transparent",
              willChange: "transform, opacity",
              WebkitBackfaceVisibility: "hidden",
              transform: "translateZ(0)",
            }}
            aria-hidden={false}
          >
            {/* Елітна тінь: ледь помітний ореол + м'яка глибина панелі */}
            <span
              aria-hidden
              className="pointer-events-none absolute rounded-2xl"
              style={{
                inset: -12,
                background: "radial-gradient(ellipse 75% 65% at 50% 50%, rgba(0,0,0,0.06) 0%, rgba(0,0,0,0.02) 55%, transparent 75%)",
                zIndex: -1,
              }}
            />
            <div
              className="relative flex flex-col overflow-hidden rounded-2xl sm:rounded-2xl flex-1 min-h-0"
              style={{
                backgroundColor: panelBackgroundColor,
                boxShadow: "0 1px 2px rgba(0,0,0,0.03), 0 3px 10px rgba(0,0,0,0.05), 0 8px 24px rgba(0,0,0,0.03)",
              }}
            >
        {/* Header — Intercom-style compact */}
        <div className="relative flex items-center gap-3 px-4 py-3 shrink-0 rounded-t-2xl sm:rounded-t-2xl" style={{ background: accentSurfaceBackground }}>
          <div className="relative flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-white/15 backdrop-blur-sm">
            <Sparkles className="h-4 w-4" style={{ color: launcherGlyphColor }} />
            <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-emerald-400 border-2 border-white/90" style={{ borderColor: accentBorderColor }} />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-[14px] font-semibold leading-tight truncate" style={{ color: headerPrimaryColor }}>{assistantName}</p>
            <p className="text-[11px] leading-tight" style={{ color: headerSecondaryColor, opacity: 0.92 }}>Online — replies instantly</p>
          </div>
          <button
            onClick={handleCloseChat}
            className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full hover:bg-white/10 transition-colors duration-200 touch-manipulation -mr-0.5"
            style={{ color: headerPrimaryColor }}
            aria-label="Close chat"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Messages area */}
        <div ref={scrollRef} className="relative flex-1 overflow-y-auto overscroll-contain min-h-0" style={{ backgroundColor: panelBackgroundColor }}>
          <div className="flex flex-col gap-0.5 p-4 pb-2">
            {messages.map((msg, idx) => {
              const f = isFirst(idx), l = isLast(idx), isCust = msg.role === "customer"
              return (
                <div key={msg.id}>
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.22, ease: [0.25, 0.1, 0.25, 1] }}
                    className={`flex items-end gap-2 ${isCust ? "justify-end" : "justify-start"} ${f ? "mt-3" : "mt-1"}`}
                  >
                    {!isCust && (
                      <div className={`flex h-6 w-6 shrink-0 items-center justify-center rounded-full ${l ? "visible" : "invisible"}`} style={{ background: accentSurfaceBackground }}>
                        <Sparkles className="h-3 w-3" style={{ color: launcherGlyphColor }} />
                      </div>
                    )}
                    <div className="flex flex-col max-w-[78%]">
                      <div
                        className={`px-3.5 py-2.5 text-[13.5px] leading-[1.55] whitespace-pre-wrap break-words ${bubbleRadius(isCust, f, l)} ${
                          isCust ? "" : "shadow-[0_1px_3px_rgba(0,0,0,0.06)]"
                        }`}
                        style={isCust ? { background: accentGradient ? accentSurfaceBackground : resolvedUserBubbleColor, color: customerMessageColor } : { background: assistantBubbleColor, color: assistantMessageColor }}
                      >
                        {msg.content}
                      </div>
                      {msg.products && msg.products.length > 0 && !isCust && (
                        <div className="flex flex-wrap gap-2 mt-2">
                          {msg.products.slice(0, 6).map((p) => {
                            const productUrl = typeof window !== "undefined" ? `${window.location.origin}/products/${p.handle}` : "#"
                            const handleAddToCart = (e: React.MouseEvent) => {
                              e.preventDefault()
                              if (typeof window === "undefined" || window.parent === window) return
                              const origin = document.referrer ? new URL(document.referrer).origin : "*"
                              window.parent.postMessage(
                                { type: "replyma:addToCart", variantId: p.variantId, quantity: 1, productId: p.id, handle: p.handle, title: p.title },
                                origin
                              )
                            }
                            return (
                              <div
                                key={p.id}
                                className="flex items-center gap-2 rounded-xl border border-[#eee] overflow-hidden shadow-[0_1px_3px_rgba(0,0,0,0.06)] hover:shadow-[0_2px_8px_rgba(0,0,0,0.08)] transition-shadow w-full max-w-[220px] min-w-0 bg-white"
                              >
                                <a href={productUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 min-w-0 flex-1 shrink-0">
                                  {p.featuredImage ? (
                                    <img src={p.featuredImage} alt="" className="h-14 w-14 object-cover shrink-0" />
                                  ) : (
                                    <div className="h-14 w-14 shrink-0 flex items-center justify-center bg-[#f5f5f5]" aria-hidden><ShoppingBag className="h-5 w-5 text-[#999]" /></div>
                                  )}
                                  <div className="flex-1 min-w-0 py-2 pr-1">
                                    <p className="text-[12px] font-medium text-[#1a1a1a] truncate">{p.title}</p>
                                    <p className="text-[11px] text-[#666] mt-0.5">${p.price}</p>
                                    <span className="text-[11px] font-medium" style={{ color: resolvedAccent }}>View product</span>
                                  </div>
                                </a>
                                <button
                                  type="button"
                                  onClick={handleAddToCart}
                                  className="shrink-0 mx-2 mb-2 mt-1 px-2.5 py-1.5 rounded-lg text-[11px] font-medium text-white hover:opacity-90 active:scale-[0.98] transition-all touch-manipulation"
                                  style={{ background: resolvedAccent }}
                                >
                                  Add to cart
                                </button>
                              </div>
                            )
                          })}
                        </div>
                      )}
                      {l && <span className={`mt-1 text-[10px] text-[#aaa] ${isCust ? "text-right mr-1" : "ml-1"}`}>{msg.time}</span>}
                    </div>
                  </motion.div>

                  {/* Quick reply chips — Intercom-style pills */}
                  {msg.quickReplies && l && !isCust && idx === messages.length - 1 && !isTyping && (
                    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2, delay: 0.12 }} className="flex flex-wrap gap-2 mt-2 ml-8">
                      {msg.quickReplies.map((qr) => (
                        <button key={qr} onClick={() => handleQuickReply(qr)} className="rounded-full px-3.5 py-2 text-[12.5px] font-medium shadow-[0_1px_3px_rgba(0,0,0,0.06)] hover:opacity-90 active:scale-[0.98] transition-all duration-150 touch-manipulation" style={{ backgroundColor: quickReplyBackgroundColor, color: quickReplyChipTextColor, border: `1px solid ${quickReplyBorderColor || accentBorderColor}` }}>
                          {qr}
                        </button>
                      ))}
                    </motion.div>
                  )}
                </div>
              )
            })}

            {/* Typing indicator */}
            {isTyping && (
              <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.2 }} className="flex items-end gap-2 mt-3">
                <div className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full" style={{ background: accentSurfaceBackground }}>
                  <Sparkles className="h-3 w-3" style={{ color: launcherGlyphColor }} />
                </div>
                <div className="flex items-center gap-1.5 rounded-2xl shadow-[0_1px_3px_rgba(0,0,0,0.06)] px-4 py-3" style={{ backgroundColor: assistantBubbleColor }}>
                  {[0, 1, 2].map((i) => (
                    <motion.span key={i} className="h-1.5 w-1.5 rounded-full bg-[#999]" animate={{ opacity: [0.4, 1, 0.4] }} transition={{ duration: 0.8, repeat: Infinity, delay: i * 0.15, ease: "easeInOut" }} />
                  ))}
                </div>
              </motion.div>
            )}
          </div>

          {/* Scroll to bottom */}
          {showScrollBtn && (
            <div className="sticky bottom-2 flex justify-center pointer-events-none">
              <button onClick={scrollToEnd} className="pointer-events-auto flex h-8 w-8 items-center justify-center rounded-full bg-white shadow-[0_2px_8px_rgba(0,0,0,0.1)] text-[#666] hover:text-[#0a0a0a] hover:shadow-[0_2px_12px_rgba(0,0,0,0.12)] transition-all duration-200">
                <ArrowDown className="h-4 w-4" />
              </button>
            </div>
          )}
        </div>

        {/* Email collection — after 1st customer message */}
        {!emailCollected && customerMsgCount >= 1 && (
          <div className="border-t border-black/[0.06] px-4 py-2.5 shrink-0" style={{ backgroundColor: panelBackgroundColor }}>
            <form onSubmit={(e) => { e.preventDefault(); if (customerEmail.includes("@")) setEmailCollected(true) }} className="flex items-center gap-2">
              <input type="email" value={customerEmail} onChange={(e) => setCustomerEmail(e.target.value)} placeholder="Your email (for follow-ups)" className={`flex-1 min-w-0 rounded-lg border border-black/[0.06] px-3 placeholder:text-[#aaa] focus:outline-none focus:ring-1 focus:ring-black/5 ${compactEmbedSizing ? "h-9 text-[12px]" : "h-9 text-[12.5px]"}`} style={{ backgroundColor: inputBackgroundColor, color: inputFieldTextColor }} />
              <button type="submit" disabled={!customerEmail.includes("@")} className="rounded-lg px-3 h-9 text-[12px] font-medium disabled:opacity-30 touch-manipulation shrink-0" style={{ background: accentSurfaceBackground, color: launcherGlyphColor }}>Save</button>
              <button type="button" onClick={() => setEmailCollected(true)} className="text-[11px] text-[#aaa] hover:text-[#666] shrink-0 px-1">Skip</button>
            </form>
          </div>
        )}

        {/* Input — Intercom-style compact footer */}
        <div className="border-t border-black/[0.06] p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] shrink-0" style={{ backgroundColor: panelBackgroundColor }}>
          <form onSubmit={(e) => { e.preventDefault(); handleSend() }} className="flex items-center gap-2">
            <input ref={inputRef} type="text" value={input} onChange={(e) => setInput(e.target.value)} placeholder="Type your message..." disabled={isTyping} className={`flex-1 min-w-0 rounded-2xl border-0 px-4 placeholder:text-[#aaa] focus:outline-none focus:ring-2 focus:ring-black/5 disabled:opacity-40 transition-shadow duration-200 ${compactEmbedSizing ? "h-10 text-[13px]" : "h-11 sm:h-10 text-[13.5px]"}`} style={{ backgroundColor: inputBackgroundColor, color: inputFieldTextColor }} />
            <button type="submit" disabled={!input.trim() || isTyping} className={`flex shrink-0 items-center justify-center rounded-2xl hover:opacity-90 active:scale-[0.98] disabled:opacity-30 touch-manipulation transition-transform duration-150 ${compactEmbedSizing ? "h-10 w-10" : "h-11 w-11 sm:h-10 sm:w-10"}`} style={{ background: accentSurfaceBackground, color: launcherGlyphColor }}>
              <Send className="h-4 w-4" />
            </button>
          </form>
          <a href="https://replyma.com" target="_blank" rel="noopener noreferrer" className="mt-2 flex items-center justify-center gap-1 text-[10px] text-[#bbb] hover:text-[#888] transition-colors duration-200">
            <Sparkles className="h-2.5 w-2.5" />
            Powered by Replyma
          </a>
        </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── Launcher (always visible; on embed mobile hide when chat open so full screen) + Proactive when closed ─── */}
      <div
        className={`z-10 flex flex-col items-end gap-3 transition-opacity duration-200 ${
          embedMode ? (embedMobile ? "fixed right-4 bottom-4 m-0 pb-[env(safe-area-inset-bottom)]" : "fixed m-0 pb-[env(safe-area-inset-bottom)]") : "relative m-4 sm:m-0"
        }`}
        style={{
          ...((embedMobile || (floatingOnly && !embedMode && isPhoneViewport)) && open ? { opacity: 0, visibility: "hidden" as const, pointerEvents: "none" } : {}),
          ...(embedMode ? {
            background: "transparent",
            minWidth: 56,
            minHeight: 56,
            isolation: "isolate" as const,
            transform: "translateZ(0)" as const,
            ...(embedMobile ? {} : { right: EMBED_DESKTOP_LAUNCHER_INSET_PX, bottom: EMBED_DESKTOP_LAUNCHER_INSET_PX }),
          } : {}),
        }}
      >
        <AnimatePresence>
          {!open && proactiveShown && !proactiveDismissed && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 6 }}
              transition={{ duration: 0.26, ease: [0.25, 0.1, 0.25, 1] }}
              className="relative max-w-[260px] rounded-2xl rounded-br-md px-4 py-3 shadow-[0_4px_20px_rgba(0,0,0,0.12)] cursor-pointer"
              style={{
                backgroundColor: proactiveBackgroundColor,
                transform: "translateX(calc(28px - 50%))",
              }}
              onClick={handleLauncherOpen}
            >
              <button onClick={(e) => { e.stopPropagation(); setProactiveDismissed(true); setProactiveShown(false) }} className="absolute -top-1.5 -right-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-white/95 text-[#999] hover:text-[#333] shadow-[0_1px_4px_rgba(0,0,0,0.1)] transition-colors duration-200" aria-label="Dismiss">
                <X className="h-3 w-3" />
              </button>
              <div className="relative flex items-start gap-2.5">
                <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full mt-0.5" style={{ background: accentSurfaceBackground }}>
                  <ShoppingBag className="h-3.5 w-3.5" style={{ color: launcherGlyphColor }} />
                </div>
                <div>
                  {proactiveMessage ? (
                    <p className="text-[13px] font-medium leading-snug whitespace-pre-wrap" style={{ color: proactivePrimaryColor }}>{proactiveMessage}</p>
                  ) : (
                    <>
                      <p className="text-[13px] font-medium leading-snug" style={{ color: proactivePrimaryColor }}>{proactiveTitle}</p>
                      <p className="text-[11px] mt-0.5" style={{ color: proactiveSecondaryColor }}>{proactiveSubtitle}</p>
                    </>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="relative inline-flex items-center justify-center">
          {/* М’яке затемнення навколо кнопки, зникає з відстанню */}
          <span
            aria-hidden
            className="pointer-events-none absolute rounded-full"
            style={{
              inset: -14,
              background: "radial-gradient(circle at center, rgba(0,0,0,0.25) 0%, rgba(0,0,0,0.08) 50%, transparent 72%)",
            }}
          />
          <LauncherButton
            isOpen={open}
            onToggle={() => (open ? handleCloseChat() : handleLauncherOpen())}
            embedMode={embedMode}
            reducedMotion={!!prefersReducedMotion}
            background={accentSurfaceBackground}
            iconColor={launcherGlyphColor}
            auraBackground={launcherAuraBackground}
            unread={unread}
          />
        </div>
      </div>
    </div>
  )
}




